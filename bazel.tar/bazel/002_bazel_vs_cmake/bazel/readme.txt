===========================================================
overview
===========================================================
 This example shows how to build C++ files to a binary with
 bazel and CMakeLists.txt
 
 <this_dir>/
   |-- WORKSPACE
   |-- run.scr
   |-- clear.scr
   +-- prj/
        |-- BUILD
        |-- include/
        |     +-- Car.hpp 
        |    
        +-- src/
              +-- main.cpp    
              +-- Car.cpp    




===========================================================
explanation
===========================================================
1. in file BUILD

    load("@rules_cc//cc:defs.bzl", "cc_binary") # load rule cc_binary

    cc_binary(
        name = "test",  ## target binary is "test",
        srcs = ["src/Car.cpp", "src/main.cpp", "include/Car.hpp"],
               ## for rule cc_binary, we need to add
               ##  1) source file: path + filename
               ##  2) header file: path + filename
               ##  3) the path is relative to this BUILD
    )
    [Note] the path of source file is relative to this BUILD file

2. run bazel for building 
    bazel //prj:test ## The BUILD is located in ./prj
                     ## bazel use target "test" defined in prj/BUILD 


===========================================================
How to run
===========================================================
1.  build with bazel 
    in <this dir>, type
     bazel build //prj:test 
        # //prj: tells bazel, the BUILD is located in ./prj/
        # test:  this is the target defined in ./prj/BUILD

2.  Build with bazel 
    . run.scr

3.  Build with CMakeLists.txt 
      . clear.scr
      cd build/
      cmake ../ && make 
      
4.  Bazel use label to reference targets
       //path/to/package: target_name


===========================================================
Question/Notes
===========================================================
1.  how to build
     in workspace type: 
        bazel build //src:test

2.  where is the built binary located ?
      in bazel-bin/prj/test

3.  how can I know the list of attributes for the rule cc_binary 
       https://docs.bazel.build/versions/main/be/c-cpp.html#cc_binary.includes

4.  how should the source code (main.cpp) include header?
      You should add relative path in include statement, like this:

      #include "prj/include/Car.hpp"

      The path "prj/include" is relative to the workspace, where the WORKSPACE is located 

      refer to : https://docs.bazel.build/versions/main/bazel-and-cpp.html#include-paths

5.  As bazel requests to add relative path to include statement, can we 
    compile the code with CMakeLists.txt?
      1) place you CMakeLists.txt at the same location as WORKSPACE
      2) In CMakeLists.txt, add following line:
            include_directories(./)
         This means the include diretory is at the place where CMakeLists.txt
         is located. So, the #include "prj/include/Car.hpp"
         will work for both bazel and CMakeLists.txt


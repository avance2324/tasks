#include "stdlib.h"
#include "stdio.h"
using namespace std;

class Car {

private:
    string name {};

public:
    Car (string name): name {name} {};
    string get_name();

} ;
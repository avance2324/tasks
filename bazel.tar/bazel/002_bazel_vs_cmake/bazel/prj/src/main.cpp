#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "prj/include/Car.hpp"

using namespace std ;



int main() {


    printf("\n");
    cout <<">>>>>>>>>>>> [start of test] >>>>>>>>>>>>" << endl ;
    Car car("BMW");

    string name = car.get_name();
    printf("name : %s \n", name.c_str());
    

    cout <<"<<<<<<<<<<<<< [end of test] <<<<<<<<<<<<<" << endl ;


}
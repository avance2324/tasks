#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include "prj/include/Car.hpp"

string Car::get_name() {
    return name ;
}


Overview
===============================================
  this example shows how to use shared library

  The shared library and header file are copied from 006_*
  to main/lib

how to run
===============================================
1.  . build.scr
    . run.scr


how to debug
===============================================
1.  debug main.cpp
-------------------------------------
    code .
    cd main 
    . build.scr
    set break point in main.cpp 
    press F5

2.  debug print.cpp
-------------------------------------
   1) cd  ../006_build_share_lib
   2) code .
   2) . build.scr
   3) cd ../007_use_share_lib/main
   4)  . build.scr
   5) in vscode, add break point in print.cpp    
   6) press F5





Question/Notes
===============================================
1.  how to specify the include path ?
    When build binary using the shared library, you need to 
    do following:
    1) add .so and header file to the srcs:
    ---------------------------------------
     srcs = [
             ...
             "lib/libprint.so",
             "lib/print.hpp",
             ],
    
    2) use copts to specify the path of header
    -------------------------------------------
         copts = [
                 ...
                 "-Imain/lib",
                 ],   

2.  The path of header set in copts should match the one in
    srcs.
        if in srcs = "print.hpp"
           in copts:  "-Imain/lib"
        It will not work, event in main/ there is a 
        print.hpp

3.  How can I tell bazel to get header and shared library 
    out of current package?
    <= I don't know for the moment

    

#include "main.hpp"
#include "print.hpp"

int main()
{
    int c ;
    std::string str ;     
    int a = 1 ;
    int b = 2 ;
    c = a + b ;
    str = "Hello World" ;

    print(str);
    printf("c = %d \n", c);
    return 1 ;

}
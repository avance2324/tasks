# These are example snippets and BUILD files for [Bazel](https://github.com/bazelbuild/bazel).

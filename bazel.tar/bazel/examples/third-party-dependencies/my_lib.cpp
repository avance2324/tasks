#include "my_lib.h"

namespace my_lib {
    int sum( int left, int right )
    {
        return left + right;
    }
}

Overview
===================================================
  build target with option --compilation_mode=dbg
  so that we can debug the source code.


How to 
===================================================
1.  . run.scr
2.  code .
3.  set breakpoint in file main/hello-world.cc
4.  press F5 to debug



Question/Notes
====================================================
1.  how to print predefined variables of vscode
    <= create a .vscode/task.json, then Terminal -> Run task
       -> select echo -> select gcc 
       Then you will see the 

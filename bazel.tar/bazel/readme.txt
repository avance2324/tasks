Overview
======================================================
This is some tutorials to show how to build with bazel
To build with bazel, you need: 

001_hello_world: 
    basic example of bazel

002_bazel_vs_cmake: 
    simple bazel project with header, multi source
    compare with cmake

003_bazel_multi_build
    a bazel project with hierarchical structure and multiple BUILD file
    source code comes from difference folders 


004_bazel_debug
    build for debug



Installation
==================

echo "deb [arch=amd64] http://storage.googleapis.com/bazel-apt stable jdk1.8" | sudo tee /etc/apt/sources.list.d/bazel.list
$ curl https://bazel.build/bazel-release.pub.gpg | sudo apt-key add -
$ sudo apt-get update
$ sudo apt-get install bazel

Structure
===================
  <dir>/ # workspace root
    |-- WORKSPACE # indicates this is workspace root, can be empty file 
    |-- clean.scr
    |-- run.scr
    |-- build.scr
    +-- main/
          |-- BUILD ## indicates the <dir>/main is a package
          +-- hello-world.cc

   BUILD: define the build rule
      name: name of the rule, it is the target, "my_app"
      srcs: list of source file, ["my_app.cc"]
      deps: list of dependencies: ["//absl/base", "//absl/strings",]
      data: some data files needed for running or testing: ["//data:fiel.txt", "//data:file2.txt",]

Examples
======================================================

1.  001_hello_world
------------------------------------------------------
  Structure
  ===========
    001_hello_world/
       |
       |-- WORKSPACE # empty file to indicate workspace root
       |-- clean.scr # clear
       |-- build.scr # run bazel build command
       |-- run.scr   # run bazel build and then test the generated binary file
       +-- main/
            |-- BUILD # specify target name, source files, etc
            +-- hello-world.cc
        
  How to
  ============
    cd 001_hello_world
    . run.scr 


2.  002_bazel_vs_cmake
------------------------------------------------------
  Structure
  ===========
    see 002_bazel_vs_cmake/bazel/readme.txt



5.  005_bazel_debug
------------------------------------------------------
    

  How to
  ============
    cd 001_hello_world
    . run.scr 


Questions and Notes
===========================================================
1.  how to build
     in workspace type: 
        bazel build //src:test

2.  where is the built binary located ?
      in bazel-bin/prj/test

3.  how can I know the list of attributes for the rule cc_binary 
       https://docs.bazel.build/versions/main/be/c-cpp.html#cc_binary.includes

4.  how should the source code (main.cpp) include header?
      You should add relative path in include statement, like this:

      #include "prj/include/Car.hpp"

      The path "prj/include" is relative to the workspace, where the WORKSPACE is located 

      refer to : https://docs.bazel.build/versions/main/bazel-and-cpp.html#include-paths

5.  As bazel requests to add relative path to include statement, can we 
    compile the code with CMakeLists.txt?
      1) place you CMakeLists.txt at the same location as WORKSPACE
      2) In CMakeLists.txt, add following line:
            include_directories(./)
         This means the include diretory is at the place where CMakeLists.txt
         is located. So, the #include "prj/include/Car.hpp"
         will work for both bazel and CMakeLists.txt
  
6.  how to add multiple targets in a BUILD file?
    <= refer to examples/cpp-tutorial/stage2/main/BUILD
       it contains 2 targets: "hi-greet" and "hi-world"
        
        ## build library hello-greet
        cc_library(
            name = "hi-greet",
            srcs = ["hello-greet.cc"],
            hdrs = ["hello-greet.h"],
        )

        ## mao: cc_binary depends on cc_library
        cc_binary(
            name = "hi-world",
            srcs = ["hello-world.cc"],
            deps = [
                ":hi-greet",
            ],
        ) 

7.  for a BUILD file containing multiple targets, how to select which target to build?
    <= use command: bazel build //<path to package>:<target>
       for example in stage2
          bazel build //main:hi-world
       or bazel build //main:hi-greet

8.  


            

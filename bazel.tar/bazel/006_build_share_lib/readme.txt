Overview
=================================================
 build shared library libprint.so and copy to ./lib/
 
 you should deliver 2 files :
   1) include/print.hpp
   2) lib/libprint.so


how to debug
===================================================
   1) code .
   2) . build.scr
   3) cd ../007_use_share_lib/main
   4)  . build.scr
   5) in vscode, add break point in print.cpp    
   6) press F5

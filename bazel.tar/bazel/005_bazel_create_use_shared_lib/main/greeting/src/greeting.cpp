#include "greeting.hpp"


std::string greeting()
{
    std::string say_hello = "Hello" ;

    return say_hello;
}
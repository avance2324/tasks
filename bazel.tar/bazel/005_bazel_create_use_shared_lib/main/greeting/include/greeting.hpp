#ifndef GREETING_HPP
#define GREETING_HPP
#include <string>

std::string greeting();

#endif // GREETING_HPP
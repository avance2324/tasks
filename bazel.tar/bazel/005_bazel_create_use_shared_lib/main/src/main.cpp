#include "main.hpp"

int main()
{
    int c ;
    std::string str ;     
    int a = 1 ;
    int b = 2 ;
    c = algo(a, b) ;

    str = greeting();
    print(str);
    printf("c = %d \n", c);
    return 1 ;

}
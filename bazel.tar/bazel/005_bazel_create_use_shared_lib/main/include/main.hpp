#ifndef MAIN_HPP
#define MAIN_HPP

#include "greeting.hpp"
#include "print.hpp"
#include "algo.hpp"
#include <string>

#endif // MAIN_HPP
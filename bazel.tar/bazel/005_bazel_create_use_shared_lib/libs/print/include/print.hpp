#ifndef PRINT_HPP
#define PRINT_HPP

#include "stdlib.h"
#include "stdio.h"
#include <string>
#include <iostream>

void print( std::string ) ;

#endif // PRINT_HPP
#include "algo.hpp"
int algo(int a, int b)
{
    int c = a + b ; 
    printf("algo(%d, %d) =  %d \n", a, b, c) ;
    return c ;

}
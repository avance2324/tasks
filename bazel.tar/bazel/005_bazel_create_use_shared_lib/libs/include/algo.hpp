#ifndef ALGO_HPP
#define ALGO_HPP

#include "stdlib.h"
#include "stdio.h"

int algo(int a, int b);

#endif // ALGO_HPP

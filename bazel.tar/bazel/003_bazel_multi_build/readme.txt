Overview
==========================================================
This bazel project with hierarchical structure and multiple BUILD file
This example mix library and source files
  1) libraries: 
  -------------
     libs/lib_algo 
     libs/lib_print 

  2) source
  -------------
     main/
     greeting/


structure
==========================================================
003_bazel_multi_build
 |
 |-- WORKSPACE
 |
 |-- main/             ## main source
 |    |
 |    |-- BUILD
 |    |
 |    |-- src
 |    |
 |    +-- include
 |    |    
 |    +-- greeting       # <= source
 |          |
 |          |-- src
 |          |
 |          +-- include
 |    
 +-- libs               
      |
      |-- lib_algo      # lib   
      |     |
      |     |-- BUILD
      |     |
      |     |-- src
      |     |
      |     +-- include
      |
      +-- lib_print     # lib
            |
            |-- BUILD
            |
            |-- src
            |
            +-- include

How to run
=======================================================================
1.  . run.scr


How to debug
=======================================================================
1.  code .
2.  open file libs/lib_print/src/print.cpp
    set break point
    F5
    


Question/Notes
=======================================================================
1.  Does cc_binary rule allow to use hdrs ?
    <= No. Only cc_library rule allow hdrs 

2.  Can I tell bazel the path of header files of cc_library?
    <= use copts, see libs/lib_algo
        copts = ['-Ilibs/lib_algo/include']
        # Note-1: this path should be set in lib/lib_algo/BUILD

3.  Can the source file such as greeting.cpp be located "outside"
    of the scope of BUILD of main? for example move greeting/ out from main/?
    <= no. If you want to include greeting.cpp in srcs of cc_binary.
       then it should be in the "scope" of BUILD of main.

4.  Can the libraray file such as print.cpp be located "outside"
    of the scope of BUILD of main?
    <= yes. For that 
    
5.  Where does bazel place the build results?
    <= in bazel-bin/<package>/

6.  In this example why I don't place BUILD in greeting/?
    <= because if you place BUILD in greeting/ then the greeting/
       become a package. And the target of a package is either a 
       binary or a library
       
7.  It seems it is not necessary to set the LD_LIBRARY_PATH for debugging
    the print.cpp or algo.cpp, why ?
    <= because the algo and print have been linked to test, as test
       depends on them.

8.  Notes: About set search path for header with -copts 
    Note-1:  the copts = ['-Ilibs/lib_algo/include'] should be set in 
             BUILD file which is used to build this target.
             Add this line to main/BUILD will help.
    Note-2:  The path is relative to WORKSPACE
    Note-3:  If you set include path in BUILD, then in #include of source 
             you don't need to specify path 
               #include "algo.hpp"
             If you don't set include path in BUILD, you should specify 
             (relative) path of header file
               #include "../include/algo.hpp"
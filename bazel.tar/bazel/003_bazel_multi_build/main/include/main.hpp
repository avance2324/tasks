#ifndef MAIN_HPP
#define MAIN_HPP

#include "greeting.hpp"
#include "algo.hpp"
#include "print.hpp"
#include <string>

#endif // MAIN_HPP
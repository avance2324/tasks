// Note: If you don't specify include path in BUILD, then you need 
//       add path to #include
//       If you specify include path in BUILD, you can omit path 
//       in #include statement
#include "../include/print.hpp"
//#include "print.hpp"
#include <vector>

void print(std::string data )
{

    std::vector<int> v = {2,3,4,23,6,7,8,10};
    int j = 0 ;
    for (const int& i: v) {
        std::cout << "[print " << i << " ] ... " << data << std::endl;
        j += i ;
    }
    std::cout << "j = " << j << std::endl ;

}
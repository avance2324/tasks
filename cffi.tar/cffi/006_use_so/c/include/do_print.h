#ifndef DO_PRINT_H
#define DO_PRINT_H
#include "stdlib.h"
#include "stdio.h"

void do_print(int c);
#endif // DO_PRINT_H
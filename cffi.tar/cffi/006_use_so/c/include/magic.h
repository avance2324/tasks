// magic.h
// Add two numbers (where a + b is not greater than INT_MAX).
#include <stdlib.h>
#include <stdio.h>
#include "do_print.h"
int glob_var_10 = 10 ;
int glob_var_20 = 20 ;

int add(int a, int b);

#include "do_print.h"
void do_print(int c) {
    printf("do_print(%d)\n", c);
}
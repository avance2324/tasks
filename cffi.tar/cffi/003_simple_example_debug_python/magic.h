// magic.h
// Add two numbers (where a + b is not greater than INT_MAX).
int add(int a, int b);

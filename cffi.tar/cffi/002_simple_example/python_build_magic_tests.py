from magic_tests import ffi, lib


print(f"3+5 = {lib.add(3,5)}")

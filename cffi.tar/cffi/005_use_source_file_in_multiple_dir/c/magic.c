// magic.c
// Implementation of magic.
#include "magic.h"
int add(int a, int b)
{

    printf("add(%d, %d) ... \n", a, b) ;
    return a+b+2;
}



// magic.h
// Add two numbers (where a + b is not greater than INT_MAX).
#include <stdlib.h>
#include <stdio.h>
int add(int a, int b);
